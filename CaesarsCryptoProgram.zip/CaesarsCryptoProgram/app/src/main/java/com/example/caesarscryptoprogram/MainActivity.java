package com.example.caesarscryptoprogram;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void criptografar(View view) {
        EditText texto = findViewById(R.id.editTextTexto);
        String txt = texto.getText().toString();
        EditText senha = findViewById(R.id.editTextNumberChave);
        int chave = Integer.valueOf(senha.getText().toString());

        String resposta = "";
        for(int i=0, j=0; i<txt.length(); i++) {
            char c = txt.charAt(i);
            c+=chave;
            if((c+0) > 122) {
                c-=26;
            }

            resposta+=c;
        }

        TextView resultado = findViewById(R.id.textViewCriptogtafia);
        resultado.setText(resposta);
    }
}